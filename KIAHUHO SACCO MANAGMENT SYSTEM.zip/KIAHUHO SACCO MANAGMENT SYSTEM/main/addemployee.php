<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveemp.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Shareholder</h4></center>
<hr>
<div id="ac">
<span>Name : </span><input type="text" style="width:265px; height:30px;" name="name" placeholder="Employee Name" Required/><br>
<span>Username: </span><input type="text" style="width:265px; height:30px;" name="sname" placeholder="Username" Required/><br>
<span>Password: </span><input type="text" style="width:265px; height:30px;" name="lname" placeholder="password" Required/><br>


<div style="float:right; margin-right:10px;">
<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>
</form>