<?php
session_start();
include('../connect.php');
$a = $_POST['name'];
$b = $_POST['username'];
$c = $_POST['password'];

// query
$sql = "INSERT INTO accounts (name,username,password) VALUES (:a,:b,:c,)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c));
header("location: employee.php");
 

?>