<div class="span2">
          <div class="well sidebar-nav">
                     <ul class="nav nav-list">
              <li class="active"><a href="index.php"><i class="icon-home icon-2x"></i> Home </a></li> 
			<li><a href="customer.php"><i class="icon-group icon-2x"></i> Shareholder</a>  </li>              
			<li><a href="savings.php"><i class="icon-list-alt icon-2x"></i> Savings</a>                                     </li>
			<li><a href="shares.php"><i class="icon-money icon-2x"></i> Shares</a>                                    </li>
			<li><a href="loans.php"><i class="icon-money icon-2x"></i> Loans</a>                                    </li>
			<li><a href="reports.php"><i class="icon-bar-chart icon-2x"></i> Reports</a>                </li>
			<br><br><br><br><br><br>		
			<li>
			 <div class="hero-unit-clock">
		
			<form name="clock">
			<font color="white">Design by: <br></font>&nbsp; Antony
			</form>
			  </div>
			</li>
				</ul>                               
          </div><!--/.well -->
        </div>